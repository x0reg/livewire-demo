   <li>
       <a class="dropdown-item" href="{{ route('logout') }}" wire:click.prevent="logout"><i
               class="bi bi-box-arrow-right me-2 fs-5"></i>
           Đăng Xuất</a>
   </li>
