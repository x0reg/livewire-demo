   <li>
       <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" wire:click.prevent="logout"><i
               class="bi bi-box-arrow-right me-2 fs-5"></i>
           Đăng Xuất</a>
   </li>
<?php /**PATH C:\laragon\www\Laravel-11\LIVEWIRE\app-demo\resources\views/livewire/user/auth/logout.blade.php ENDPATH**/ ?>