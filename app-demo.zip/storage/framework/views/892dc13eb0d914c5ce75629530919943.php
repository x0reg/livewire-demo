<div>
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">Create a beautiful dashboard </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Laravel-11\LIVEWIRE\app-demo\resources\views/livewire/user/dashboard.blade.php ENDPATH**/ ?>