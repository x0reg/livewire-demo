<div>
    <!-- Toast notifications -->
    <?php if(session()->has('success')): ?>
        <script>
            window.addEventListener('load', () => {
                Flasher.create('success', "<?php echo e(session('success')); ?>", {
                    // Options cho toast
                });
            });
        </script>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <script>
            window.addEventListener('load', () => {
                Flasher.create('error', "<?php echo e(session('error')); ?>", {
                    // Options cho toast
                });
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('warning')): ?>
        <script>
            window.addEventListener('load', () => {
                Notyf.create('warning', "<?php echo e(session('warning')); ?>", {
                    // Options cho toast
                });
            });
        </script>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\Laravel-11\LIVEWIRE\app-demo\resources\views\livewire\user\layouts\toast.blade.php ENDPATH**/ ?>