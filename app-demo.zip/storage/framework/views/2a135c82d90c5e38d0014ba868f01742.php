<div>
    
    <style>
        .login-content .login-box {
            min-width: 361px;
            min-height: 700px;
        }
    </style>
    <form class="login-form" wire:submit.prevent='register'>
        <h3 class="login-head"><i class="bi bi-person me-2"></i>ĐĂNG KÍ</h3>
        <p>Nếu có tài khoản <a href="<?php echo e(route('login')); ?>" class="text-danger fw-bold text-decoration-none"
                wire:navigate>Đăng nhập ngay</a></p>
        <div class="mb-3">
            <label class="form-label">Họ và tên</label>
            <input class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="họ và tên"
                id="name" wire:model="name"autofocus>
            <!--[if BLOCK]><![endif]--><?php if($errors->has('name')): ?>
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label class="form-label">Tên Đăng Nhập</label>
            <input class="form-control  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                placeholder="Tên đăng nhập" id="username" wire:model='username' autofocus>
            <!--[if BLOCK]><![endif]--><?php if($errors->has('username')): ?>
                <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email"
                placeholder="example@email.com" id="email" wire:model='email' autofocus>
            <!--[if BLOCK]><![endif]--><?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label class="form-label">Mật khẩu</label>
            <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " type="password" id="password"
                wire:model='password' placeholder="Password">
            <!--[if BLOCK]><![endif]--><?php if($errors->has('password')): ?>
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="mb-3">
            <label class="form-label">Nhập lại Mật khẩu</label>
            <input class="form-control  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password"
                id="password_confirmation" wire:model='password_confirmation' placeholder="Password">
            <!--[if BLOCK]><![endif]--><?php if($errors->has('password_confirmation')): ?>
                <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mb-3 btn-container d-grid">
            <button class="btn btn-primary btn-block" wire:loading.attr="disabled">
                <span wire:loading.remove wire:target="register">
                    <i class="bi bi-box-arrow-in-right me-2 fs-5"></i>ĐĂNG KÍ
                </span>
                <span wire:loading wire:target="register">
                    <div class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></div> Đang xử lý...
                </span>
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\laragon\www\Laravel-11\LIVEWIRE\app-demo\resources\views/livewire/user/auth/register.blade.php ENDPATH**/ ?>