<?php

namespace App\Livewire\User\Layouts;

use Livewire\Component;

class Sidebar extends Component
{
    public function render()
    {
        return view('livewire.user.layouts.sidebar');
    }
}
